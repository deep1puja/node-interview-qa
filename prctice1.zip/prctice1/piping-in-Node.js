
/*
Piping is a MECHANISM used to connect the OUTPUT OF ONE STREAM TO ANOTHER STREAM.
It is normally used to retrieve data from one stream and pass output to another stream
*/




