const sinupctrl= require("./signup-cntrl")
module.exports=(route)=>{

route.get('/test',sinupctrl.fun1);
 

}