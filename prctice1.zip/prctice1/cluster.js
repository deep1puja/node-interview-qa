/*As a solution, Node. js introduced the cluster module,

"which creates multiple copies of the same application on the same machine and has them running at the same time."

It also comes with a load balancer that evenly distributes the load among the processes using the round-robin algorithm



*/

var cluster = require('cluster');

if (cluster.isWorker) {
    console.log('I am a worker');
} else {
    console.log('I am a master');
    cluster.fork();
    cluster.fork();
}