//--- CALL APPLY BIND
// The call() method does not make a copy of the function it is being called on.
// call() and apply() serve the exact same purpose.
// The only difference between how they work is that call() expects all parameters to be passed in individually,
// whereas apply() expects an array of all of our parameters.
// Example:
function showData(input, input2) {

    console.log(this.txtName, input, input2);
}

showData.call({ txtName: "OM" }, 101, 501);
showData.apply({ txtName: "Shiv" }, [101, 501]);

let res = showData.bind({ txtName: "Shiv" }, 101, 501);
res();
