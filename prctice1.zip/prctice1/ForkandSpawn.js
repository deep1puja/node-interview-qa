/*
Fork creates a child process that is a copy of the parent process,
spawn:- while spawn creates a new process from scratch.
 
 Exec is typically used for short - lived processes, while fork and spawn are typically used for long - lived processes
*/
