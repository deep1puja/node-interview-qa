/*
 Middleware functions are functions that have access to the request object (req), the response object (res),
 and the next function in the application’s request-response cycle.
 The next function is a function in the Express router which, when invoked, executes the middleware succeeding the current middleware.

*/

const express = require('express')
const app = express()

// this is middleware Function it prints the message “LOGGED” to the terminal.
const requestTime = function (req, res, next) {
    req.requestTime = Date.now()
    next()
}


app.use(requestTime)

app.get('/', (req, res) => {
    let responseText = 'Hello World!<br>'
    responseText += `<small>Requested at: ${req.requestTime}</small>`
    res.send(responseText)
})

app.listen(3000)