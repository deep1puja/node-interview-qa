/*
The async function declaration declares an async function 
where the await keyword is permitted within the function body.
The async and await keywords enable asynchronous,
 promise - based behavior to be written in a cleaner style, avoiding the need to explicitly configure promise chains
*/
const getcityname = async (pin) => {

   return pin;
}
const getData = async () => {

   const res = await getcityname(804408); // 1s , 5s 5m
   console.log(res); // undefine // <pending>

}

const res2 = await getData();


let add = (a, b) => a + b;
let sub = (a, b) => a - b;
let devide = (a, b) => a / b;
let mul = (a, b) => a * b;

let cal = async (a, b) => {
   return mul(await devide(await sub(await add(a, b), a), 1), 25);
}

//cal.then(serve);
cal(5, 8).then((res) => {
   console.log(res);
}).catch((err) => {

   console.error(err);
});
