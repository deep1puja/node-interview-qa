/*
setTimeout / clearTimeout – This is used to implement delays in code execution.
setInterval / clearInterval – This is used to run a code block multiple times.
setImmediate / clearImmediate – Any function passed as the setImmediate() argument is a callback that's executed in the next iteration of the event loop.
process.nextTick – Both setImmediate and process.nextTick appear to be doing the same thing; however, you may prefer one over the other depending on your callback’s urgency.

*/
setTimeout(() => {
  console.log('setTimeout');
}, 0);

setImmediate(() => {
  console.log('immediate');
});

process.nextTick(() => {
  console.log('nextTick');
});

/*
nextTick
setTimeout
immediate

*/