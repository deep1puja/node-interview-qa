// async wait
let fs=require("fs");
function  func1(){
return 5;
    
}

function  func2(){
  return 5;
     
}

 

b=async()=>{
   let x= await func1();

    let y= await func2();

    console.log("Total=",y+x);
    
}

b();

/// Call back
 
var filedata=fs.readFileSync("input.txt");
console.log(filedata.toString());

fs.readFile("input.txt",(err,data)=>{

    console.log(data.toString());
});

//--- CAL APPLY BIND
// The call() method does not make a copy of the function it is being called on.
// call() and apply() serve the exact same purpose.
// The only difference between how they work is that call() expects all parameters to be passed in individually,
// whereas apply() expects an array of all of our parameters.
// Example:
function showData(input,input2){

console.log(this.txtName,input,input2);
}

showData.call({txtName:"OM"},101,501);
showData.apply({txtName:"Shiv"},[101,501]);

let res=showData.bind({txtName:"Shiv"},101,501);
res();

console.log("--------------------------------------------");
//-----
let events=require("events");

let myEmitter= new events.EventEmitter();

var myEmitFunction=()=>{
    console.log("-- This is called--");

}
  
myEmitter.on("mycall",myEmitFunction);


myEmitter.emit("mycall");

