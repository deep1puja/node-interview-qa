module.exports={
  fun1: (req,res)=>{
      console.log("fun1");
      this.fun2().then((data)=>{
          console.log(data);
      }
      ).catch((e)=>{
      });
      
  },

  fun2:()=>{
    return "fun2";
    //return res.status(404).json({  status: false, message: "FUN2",error: {}});

  }

}