/*
Node provides Buffer class 
which provides instances to store raw data similar to an array of integers 
but corresponds to a raw memory allocation outside the V8 heap.
Buffer class is a global class that can be accessed in an application without importing the buffer module.

*/
// Ex. -1 equals()
var buf1 = Buffer.from('abc');
var buf2 = Buffer.from('abc');

console.log(buf1.equals(buf2));

