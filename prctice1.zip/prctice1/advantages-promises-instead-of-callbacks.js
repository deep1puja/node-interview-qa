/*

The main advantage of using promise is
    - YOU GET AN OBJECT TO DECIDE THE ACTION THAT NEEDS TO BE TAKEN AFTER THE ASYNC TASK COMPLETES.
 This gives more manageable code and AVOIDS CALLBACK HELL.

*/