 

/*
This is used TO EXPOSE FUNCTIONS of a particular module or file to be used elsewhere in the project.
This can be USED TO ENCAPSULATE ALL SIMILAR FUNCTIONS in a file which further improves the project structure.


*/
const getSolutionInJavaScript = async ({
    problem_id
}) => {
//abc
};
const getSolutionInPython = async ({
    problem_id
}) => {
// abc
};
module.exports = { getSolutionInJavaScript, getSolutionInPython }