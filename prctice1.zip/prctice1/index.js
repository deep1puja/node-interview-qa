const bodyParser = require("body-parser");
const cluster = require('cluster');
const express = require("express");
const { resolve } = require("path");
const router=express.Router();
const app=express();
const db=require("./db");
 
if (cluster.isPrimary) {
  console.log('I am primary');
  cluster.fork();
  cluster.fork();
} else if (cluster.isWorker) {
  console.log(`I am worker #${cluster.worker.id}`);
}
var conn=db();
app.listen('3000',(req,res)=>{

    console.log("-----Helloo--------------");
});
 
app.use("/api", router);

app.get("/",(req,res)=>{
    //let data= new Promise(resolve,reject);
  conn.query("select   * from students",function(err,result){
            console.log("",result);
            
            
            return res.status(200).json({"msg":"Welcome","data":result});
  })
// console.log("OKKK");
// //call, Apply, Bind()
// function test(ar1,ar2){
//     console.log(this.num,ar1,ar2);
// }
// test.call({num:10},4,5);
// test.apply({num:10},[4,5]);
// let ress=test.bind({num:10},4,5);
// ress();

// let arithmetic={

//     add:(a,b)=>{

//     return a+b;

//     },
//     sub:(a,b)=>{
//         return a-b;
//     }
// }
// console.log(arithmetic.add(5,6));
// // timeout_vs_immediate.js


//     return res.status(200).json({"msg":"Welcome"});
});
require('./signup')(router);


