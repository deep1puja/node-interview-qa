/*
We are PASSING CALLBACK FUNCTIONS and 
it makes the code UNREADABLE and not MAINTAINABLE,
thus we should change the async logic to avoid this
*/

firstFunction(args, function () {
  secondFunction(args, function () {
    thirdFunction(args, function () {
      // And so on…
    });
  });
});


let add = (a, b) => a + b;
let sub = (a, b) => a - b;
let devide = (a, b) => a / b;
let mul = (a, b) => a * b;

let cal = async (a, b) => {
  let adds = await add(a, b);
  let m = await sub(adds, a);
  let dv = devide(m, 2);
  let multi = await mul(dv, 20);
  return multi;
}

//cal.then(serve);
cal(5, 6).then((res) => {
  console.log(res);
}).catch((err) => {

  // console.error(err);
});
