const mysql=require("mysql");
module.exports= function () {
var connection=mysql.createConnection(
    {   host:"localhost",
        user:'root',
        password:'',        
        database:'gla'
    });

    connection.connect(function(err){
        if(err) 
        console.log(err);
        console.log("DB Connected");
    });
 return connection;
}