let express=require('express');

const app=express();

app.listen(8080,(req,res)=>{

    console.log("wecome..");
});