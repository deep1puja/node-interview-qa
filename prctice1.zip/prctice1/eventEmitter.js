/*
Node.js allows us to create and handle custom events easily by using events module.
Event module includes 
-->>EventEmitter class which can be used to raise and handle 
custom events.

*/
// Import events module
var events = require('events');
// Create an eventEmitter object
var eventEmitter = new events.EventEmitter();
var eventHandel= function test(){
    console.log("helloooooooo");
    eventEmitter.emit('data_received');
}
 
// Bind the data_received event with the anonymous function
eventEmitter.on('data_received', function() {
   console.log('data received succesfully.');
});

// Bind event and event  handler as follows
eventEmitter.on('connection', eventHandel);
eventEmitter.emit('connection');