const p1 = Promise.resolve(3);
const p2 = 1337;
