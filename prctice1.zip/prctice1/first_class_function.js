/*
A programming language is said to have First-class functions
 when functions in that language are treated like any OTHER VARIABLE.

*/

const Arithmetics = {
	add: (a, b) => {
		return `${a} + ${b} = ${a + b}`;
	},
	subtract: (a, b) => {
		return `${a} - ${b} = ${a - b}`
	},
	multiply: (a, b) => {
		return `${a} * ${b} = ${a * b}`
	},
	division: (a, b) => {
		if (b != 0) return `${a} / ${b} = ${a / b}`;
		return `Cannot Divide by Zero!!!`;
	}

}
let a = Arithmetics.multiply(5, 6);
console.log(a);
a = Arithmetics.add(5, 6);
console.log(a);



