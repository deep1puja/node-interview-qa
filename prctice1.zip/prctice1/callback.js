//  A callback is a function CALLED AFTER A GIVEN TASK. 
//Blocking Code Example
var fs = require("fs");
var data = fs.readFileSync('input.txt');

console.log(data.toString());

console.log("Program Ended...");


//Non-Blocking Code Example
fs.readFile("inputss.txt", (error, data) => {

    try {
        fsdfsd = sdf
        if (!error)
            consoleddds.log(data.toString());
    } catch (err) {
        console.log("EROR:---", err);

    }




});