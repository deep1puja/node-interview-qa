/*
A Node.js Promise is a placeholder for a value that will be available in the future,
allowing us to handle the result of an asynchronous task once it has completed or encountered an error.
Promises make writing asynchronous code easier.
They're an improvement on the callback pattern and very popular in Node. js.

The Promise object supports two properties: state and result.

While a Promise object is "pending" (working), the result is undefined.

When a Promise object is "fulfilled", the result is a value.

When a Promise object is "rejected", the result is an error object.
*/

await blog.save()
    .then((result) => {
        res.status(200).json({
            status: true,
            message: "Blog added successfully",
            result: result
        })
    }).catch((error) => {

    });